import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import dotenv from 'dotenv';
import {
  INITIAL_STATIONS_SEED,
  validateStationInput,
  type Station,
  type StationInput,
  type Tramo,
} from './src/types/station.ts';

dotenv.config();

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'stations.json');

const SUPABASE_URL = process.env.SUPABASE_URL?.trim().replace(/\/+$/, '') || '';
const SUPABASE_KEY =
  process.env.SUPABASE_SERVICE_ROLE_KEY?.trim() ||
  process.env.SUPABASE_ANON_KEY?.trim() ||
  '';
const SUPABASE_TABLE = 'estaciones_monitoreo';

function isSupabaseConfigured(): boolean {
  return Boolean(SUPABASE_URL && SUPABASE_KEY);
}

function getSupabaseHeaders(prefer?: string): Record<string, string> {
  const headers: Record<string, string> = {
    apikey: SUPABASE_KEY,
    Authorization: `Bearer ${SUPABASE_KEY}`,
    'Content-Type': 'application/json',
  };
  if (prefer) {
    headers.Prefer = prefer;
  }
  return headers;
}

function ensureLocalDataFile(): Station[] {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(INITIAL_STATIONS_SEED, null, 2), 'utf8');
    return [...INITIAL_STATIONS_SEED];
  }
  const raw = fs.readFileSync(DATA_FILE, 'utf8');
  const parsed = JSON.parse(raw);
  return Array.isArray(parsed) ? (parsed as Station[]) : [...INITIAL_STATIONS_SEED];
}

function saveLocalDataFile(stations: Station[]): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  fs.writeFileSync(DATA_FILE, JSON.stringify(stations, null, 2), 'utf8');
}

async function listStationsFromStore(tramoFilter?: string): Promise<Station[]> {
  if (isSupabaseConfigured()) {
    const url = new URL(`${SUPABASE_URL}/rest/v1/${SUPABASE_TABLE}`);
    url.searchParams.set('select', '*');
    url.searchParams.set('order', 'fecha_muestreo.desc,created_at.desc');
    if (tramoFilter === 'aguas arriba' || tramoFilter === 'aguas abajo') {
      url.searchParams.set('tramo', `eq.${tramoFilter}`);
    }

    const res = await fetch(url.toString(), {
      headers: getSupabaseHeaders(),
    });
    if (!res.ok) {
      const msg = await res.text();
      throw new Error(`Supabase list error (${res.status}): ${msg}`);
    }
    const rows = (await res.json()) as Station[];

    // Seed initial 3 examples if table is empty and no filter was requested
    if (rows.length === 0 && !tramoFilter) {
      const seedPayload = INITIAL_STATIONS_SEED.map((s) => ({
        nombre_punto: s.nombre_punto,
        latitud: s.latitud,
        longitud: s.longitud,
        arroyo: s.arroyo,
        fecha_muestreo: s.fecha_muestreo,
        tramo: s.tramo,
      }));
      const seedRes = await fetch(`${SUPABASE_URL}/rest/v1/${SUPABASE_TABLE}`, {
        method: 'POST',
        headers: getSupabaseHeaders('return=representation'),
        body: JSON.stringify(seedPayload),
      });
      if (seedRes.ok) {
        return (await seedRes.json()) as Station[];
      }
    }
    return rows;
  }

  let stations = ensureLocalDataFile();
  if (tramoFilter === 'aguas arriba' || tramoFilter === 'aguas abajo') {
    stations = stations.filter((s) => s.tramo === tramoFilter);
  }
  return stations.sort((a, b) => {
    const dateDiff = b.fecha_muestreo.localeCompare(a.fecha_muestreo);
    if (dateDiff !== 0) return dateDiff;
    return b.created_at.localeCompare(a.created_at);
  });
}

async function createStationInStore(input: StationInput): Promise<Station> {
  if (isSupabaseConfigured()) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${SUPABASE_TABLE}`, {
      method: 'POST',
      headers: getSupabaseHeaders('return=representation'),
      body: JSON.stringify(input),
    });
    if (!res.ok) {
      const msg = await res.text();
      throw new Error(`Supabase insert error (${res.status}): ${msg}`);
    }
    const rows = (await res.json()) as Station[];
    return rows[0];
  }

  const stations = ensureLocalDataFile();
  const created: Station = {
    id: crypto.randomUUID(),
    ...input,
    created_at: new Date().toISOString(),
  };
  stations.unshift(created);
  saveLocalDataFile(stations);
  return created;
}

async function updateStationInStore(id: string, input: StationInput): Promise<Station | null> {
  if (isSupabaseConfigured()) {
    const url = new URL(`${SUPABASE_URL}/rest/v1/${SUPABASE_TABLE}`);
    url.searchParams.set('id', `eq.${id}`);
    const res = await fetch(url.toString(), {
      method: 'PATCH',
      headers: getSupabaseHeaders('return=representation'),
      body: JSON.stringify(input),
    });
    if (!res.ok) {
      const msg = await res.text();
      throw new Error(`Supabase update error (${res.status}): ${msg}`);
    }
    const rows = (await res.json()) as Station[];
    return rows[0] || null;
  }

  const stations = ensureLocalDataFile();
  const index = stations.findIndex((s) => s.id === id);
  if (index === -1) return null;

  const updated: Station = {
    ...stations[index],
    ...input,
  };
  stations[index] = updated;
  saveLocalDataFile(stations);
  return updated;
}

async function deleteStationFromStore(id: string): Promise<boolean> {
  if (isSupabaseConfigured()) {
    const url = new URL(`${SUPABASE_URL}/rest/v1/${SUPABASE_TABLE}`);
    url.searchParams.set('id', `eq.${id}`);
    const res = await fetch(url.toString(), {
      method: 'DELETE',
      headers: getSupabaseHeaders('return=representation'),
    });
    if (!res.ok) {
      const msg = await res.text();
      throw new Error(`Supabase delete error (${res.status}): ${msg}`);
    }
    const rows = (await res.json()) as Station[];
    return rows.length > 0;
  }

  const stations = ensureLocalDataFile();
  const next = stations.filter((s) => s.id !== id);
  if (next.length === stations.length) return false;
  saveLocalDataFile(next);
  return true;
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // Runtime configuration endpoint for Maps API key when injected via container env
  app.get('/api/config', (_req, res) => {
    const googleMapsApiKey =
      process.env.VITE_GOOGLE_MAPS_API_KEY ||
      process.env.GOOGLE_MAPS_API_KEY ||
      '';
    res.json({ googleMapsApiKey });
  });

  app.get('/api/stations', async (req, res) => {
    try {
      const tramoParam = typeof req.query.tramo === 'string' ? req.query.tramo.trim().toLowerCase() : '';
      const tramo: Tramo | undefined =
        tramoParam === 'aguas arriba' || tramoParam === 'aguas abajo'
          ? (tramoParam as Tramo)
          : undefined;
      const stations = await listStationsFromStore(tramo);
      res.json(stations);
    } catch (error) {
      console.error('Error listing stations:', error);
      res.status(500).json({ error: 'No se pudieron obtener las estaciones de monitoreo.' });
    }
  });

  app.post('/api/stations', async (req, res) => {
    const validation = validateStationInput(req.body);
    if (!validation.ok || !validation.data) {
      return res.status(400).json({
        error: 'Revisá los campos ingresados.',
        fieldErrors: validation.errors,
      });
    }

    try {
      const created = await createStationInStore(validation.data);
      return res.status(201).json(created);
    } catch (error) {
      console.error('Error creating station:', error);
      return res.status(500).json({ error: 'No se pudo guardar la estación de monitoreo.' });
    }
  });

  app.put('/api/stations/:id', async (req, res) => {
    const id = req.params.id;
    const validation = validateStationInput(req.body);
    if (!validation.ok || !validation.data) {
      return res.status(400).json({
        error: 'Revisá los campos ingresados.',
        fieldErrors: validation.errors,
      });
    }

    try {
      const updated = await updateStationInStore(id, validation.data);
      if (!updated) {
        return res.status(404).json({ error: 'Estación no encontrada.' });
      }
      return res.json(updated);
    } catch (error) {
      console.error('Error updating station:', error);
      return res.status(500).json({ error: 'No se pudo actualizar la estación de monitoreo.' });
    }
  });

  app.delete('/api/stations/:id', async (req, res) => {
    const id = req.params.id;
    try {
      const deleted = await deleteStationFromStore(id);
      if (!deleted) {
        return res.status(404).json({ error: 'Estación no encontrada.' });
      }
      return res.json({ deleted: true, id });
    } catch (error) {
      console.error('Error deleting station:', error);
      return res.status(500).json({ error: 'No se pudo eliminar la estación de monitoreo.' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
