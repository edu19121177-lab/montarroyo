import { useEffect, useState, type FormEvent } from 'react';
import { Crosshair, X } from 'lucide-react';
import {
  validateStationInput,
  type Station,
  type StationInput,
  type Tramo,
} from '../types/station.ts';

interface StationFormModalProps {
  isOpen: boolean;
  formSessionKey: number;
  editingStation: Station | null;
  pickedCoordinates: { lat: number; lng: number } | null;
  onStartPickingOnMap: () => void;
  onClose: () => void;
  onSave: (input: StationInput, editingId?: string) => Promise<void>;
}

interface FormDraft {
  nombre_punto: string;
  arroyo: string;
  fecha_muestreo: string;
  tramo: Tramo;
  latitud: string;
  longitud: string;
}

function getTodayDateString(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function StationFormModal({
  isOpen,
  formSessionKey,
  editingStation,
  pickedCoordinates,
  onStartPickingOnMap,
  onClose,
  onSave,
}: StationFormModalProps) {
  const [draft, setDraft] = useState<FormDraft>({
    nombre_punto: '',
    arroyo: 'Arroyo Pereyra',
    fecha_muestreo: getTodayDateString(),
    tramo: 'aguas arriba',
    latitud: '',
    longitud: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  // Sync form only when starting a new create/edit session
  useEffect(() => {
    if (formSessionKey === 0) return;
    if (editingStation) {
      setDraft({
        nombre_punto: editingStation.nombre_punto,
        arroyo: editingStation.arroyo,
        fecha_muestreo: editingStation.fecha_muestreo,
        tramo: editingStation.tramo,
        latitud: String(editingStation.latitud),
        longitud: String(editingStation.longitud),
      });
    } else {
      setDraft({
        nombre_punto: '',
        arroyo: 'Arroyo Pereyra',
        fecha_muestreo: getTodayDateString(),
        tramo: 'aguas arriba',
        latitud: '',
        longitud: '',
      });
    }
    setErrors({});
  }, [formSessionKey, editingStation]);

  // Apply coordinates captured from clicking on Google Maps
  useEffect(() => {
    if (pickedCoordinates) {
      setDraft((prev) => ({
        ...prev,
        latitud: pickedCoordinates.lat.toFixed(6),
        longitud: pickedCoordinates.lng.toFixed(6),
      }));
      setErrors((prev) => {
        const next = { ...prev };
        delete next.latitud;
        delete next.longitud;
        return next;
      });
    }
  }, [pickedCoordinates]);

  if (!isOpen) return null;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const result = validateStationInput(draft);
    if (!result.ok || !result.data) {
      setErrors(result.errors);
      return;
    }

    setSubmitting(true);
    setErrors({});
    try {
      await onSave(result.data, editingStation?.id);
      onClose();
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Ocurrió un error al guardar el registro.';
      setErrors({ general: message });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-slate-900/45 p-4 backdrop-blur-[1px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="station-form-title"
    >
      <div className="w-full max-w-lg rounded-lg border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <h2 id="station-form-title" className="font-display text-lg font-semibold text-slate-900">
            {editingStation ? 'Editar estación de monitoreo' : 'Nueva estación de monitoreo'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar formulario"
            className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900 focus-visible:outline-2 focus-visible:outline-sky-600"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <form onSubmit={handleSubmit} noValidate className="space-y-4 px-6 py-5">
          {errors.general && (
            <div className="rounded-md border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-800">
              {errors.general}
            </div>
          )}

          <div>
            <label
              htmlFor="field-nombre-punto"
              className="block text-xs font-semibold text-slate-700"
            >
              Nombre del punto
            </label>
            <input
              id="field-nombre-punto"
              type="text"
              required
              placeholder="Ej. Puente Ruta 2 Km 41"
              value={draft.nombre_punto}
              onChange={(e) => setDraft({ ...draft, nombre_punto: e.target.value })}
              className="mt-1.5 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-sky-600 focus:outline-none"
            />
            {errors.nombre_punto && (
              <p className="mt-1 text-xs text-rose-600">{errors.nombre_punto}</p>
            )}
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="field-arroyo" className="block text-xs font-semibold text-slate-700">
                Arroyo
              </label>
              <input
                id="field-arroyo"
                type="text"
                required
                placeholder="Ej. Arroyo Pereyra"
                value={draft.arroyo}
                onChange={(e) => setDraft({ ...draft, arroyo: e.target.value })}
                className="mt-1.5 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-sky-600 focus:outline-none"
              />
              {errors.arroyo && <p className="mt-1 text-xs text-rose-600">{errors.arroyo}</p>}
            </div>

            <div>
              <label htmlFor="field-fecha" className="block text-xs font-semibold text-slate-700">
                Fecha de muestreo
              </label>
              <input
                id="field-fecha"
                type="date"
                required
                value={draft.fecha_muestreo}
                onChange={(e) => setDraft({ ...draft, fecha_muestreo: e.target.value })}
                className="mt-1.5 w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900 tabular-nums focus:border-sky-600 focus:outline-none"
              />
              {errors.fecha_muestreo && (
                <p className="mt-1 text-xs text-rose-600">{errors.fecha_muestreo}</p>
              )}
            </div>
          </div>

          <div>
            <span className="block text-xs font-semibold text-slate-700">Tramo del arroyo</span>
            <div className="mt-1.5 grid grid-cols-2 gap-1 rounded-md border border-slate-200 bg-slate-100 p-1">
              {(['aguas arriba', 'aguas abajo'] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setDraft({ ...draft, tramo: option })}
                  className={`whitespace-nowrap rounded px-3 py-2 text-xs font-medium capitalize transition-colors focus-visible:outline-2 focus-visible:outline-sky-600 ${
                    draft.tramo === option
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
            {errors.tramo && <p className="mt-1 text-xs text-rose-600">{errors.tramo}</p>}
          </div>

          <div className="rounded-md border border-slate-200 bg-slate-50 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-xs font-semibold text-slate-800">
                  Coordenadas GPS (grados decimales)
                </p>
                <p className="text-[11px] text-slate-500">
                  Latitud entre −90 y 90 · Longitud entre −180 y 180
                </p>
              </div>
              <button
                type="button"
                onClick={onStartPickingOnMap}
                className="inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-md border border-sky-200 bg-white px-2.5 py-1.5 text-xs font-medium text-sky-700 transition-colors hover:bg-sky-50 focus-visible:outline-2 focus-visible:outline-sky-600"
              >
                <Crosshair className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Elegir en el mapa</span>
              </button>
            </div>

            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label htmlFor="field-latitud" className="block text-xs font-medium text-slate-700">
                  Latitud
                </label>
                <input
                  id="field-latitud"
                  type="text"
                  inputMode="decimal"
                  required
                  placeholder="-34.842150"
                  value={draft.latitud}
                  onChange={(e) => setDraft({ ...draft, latitud: e.target.value })}
                  className="mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900 tabular-nums placeholder:text-slate-400 focus:border-sky-600 focus:outline-none"
                />
                {errors.latitud && <p className="mt-1 text-xs text-rose-600">{errors.latitud}</p>}
              </div>

              <div>
                <label htmlFor="field-longitud" className="block text-xs font-medium text-slate-700">
                  Longitud
                </label>
                <input
                  id="field-longitud"
                  type="text"
                  inputMode="decimal"
                  required
                  placeholder="-58.118420"
                  value={draft.longitud}
                  onChange={(e) => setDraft({ ...draft, longitud: e.target.value })}
                  className="mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900 tabular-nums placeholder:text-slate-400 focus:border-sky-600 focus:outline-none"
                />
                {errors.longitud && (
                  <p className="mt-1 text-xs text-rose-600">{errors.longitud}</p>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-200 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="whitespace-nowrap rounded-md border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="whitespace-nowrap rounded-md bg-sky-700 px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-sky-800 disabled:opacity-60"
            >
              {submitting
                ? 'Guardando...'
                : editingStation
                  ? 'Guardar cambios'
                  : 'Guardar estación'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
