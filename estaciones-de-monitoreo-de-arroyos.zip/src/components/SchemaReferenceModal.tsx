import { useState } from 'react';
import { Check, Copy, X } from 'lucide-react';

interface SchemaReferenceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SUPABASE_SQL = `create table if not exists public.estaciones_monitoreo (
  id uuid primary key default gen_random_uuid(),
  nombre_punto text not null,
  latitud double precision not null check (latitud >= -90 and latitud <= 90),
  longitud double precision not null check (longitud >= -180 and longitud <= 180),
  arroyo text not null,
  fecha_muestreo date not null,
  tramo text not null check (tramo in ('aguas arriba', 'aguas abajo')),
  created_at timestamptz not null default now()
);`;

const SCHEMA_COLUMNS = [
  { name: 'id', type: 'uuid', rule: 'Clave primaria única (gen_random_uuid)' },
  { name: 'nombre_punto', type: 'text', rule: 'Obligatorio · Nombre identificador de la estación' },
  { name: 'latitud', type: 'double precision', rule: 'Grados decimales · Validación −90 a 90' },
  { name: 'longitud', type: 'double precision', rule: 'Grados decimales · Validación −180 a 180' },
  { name: 'arroyo', type: 'text', rule: 'Obligatorio · Curso de agua monitoreado' },
  { name: 'fecha_muestreo', type: 'date', rule: 'Obligatorio · Formato AAAA-MM-DD' },
  { name: 'tramo', type: 'text', rule: "Restringido a 'aguas arriba' | 'aguas abajo'" },
];

export function SchemaReferenceModal({ isOpen, onClose }: SchemaReferenceModalProps) {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(SUPABASE_SQL);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored
    }
  };

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-slate-900/45 p-4 backdrop-blur-[1px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="schema-modal-title"
    >
      <div className="w-full max-w-2xl rounded-lg border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <h2 id="schema-modal-title" className="font-display text-lg font-semibold text-slate-900">
            Estructura de tabla en Supabase
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar esquema"
            className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <div className="space-y-5 px-6 py-5">
          <div className="overflow-x-auto rounded-md border border-slate-200">
            <table className="w-full border-collapse text-left text-xs">
              <thead className="border-b border-slate-200 bg-slate-50 text-slate-600">
                <tr>
                  <th className="px-3.5 py-2.5 font-semibold">Columna</th>
                  <th className="px-3.5 py-2.5 font-semibold">Tipo SQL</th>
                  <th className="px-3.5 py-2.5 font-semibold">Restricción / Propósito</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {SCHEMA_COLUMNS.map((col) => (
                  <tr key={col.name} className="bg-white">
                    <td className="px-3.5 py-2 font-mono font-medium text-slate-900">
                      {col.name}
                    </td>
                    <td className="px-3.5 py-2 font-mono text-sky-700">{col.type}</td>
                    <td className="px-3.5 py-2 text-slate-600">{col.rule}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700">
                Definición SQL (public.estaciones_monitoreo)
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1.5 rounded border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                {copied ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-600" aria-hidden="true" />
                    <span>Copiado</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Copiar SQL</span>
                  </>
                )}
              </button>
            </div>
            <pre className="overflow-x-auto rounded-md border border-slate-200 bg-slate-900 p-3.5 font-mono text-xs leading-relaxed text-slate-100">
              {SUPABASE_SQL}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
