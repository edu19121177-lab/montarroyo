import { useCallback, useEffect, useState } from 'react';
import {
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useAdvancedMarkerRef,
  useApiIsLoaded,
  useApiLoadingStatus,
  useMap,
  useMapsLibrary,
  APILoadingStatus,
  type MapMouseEvent,
} from '@vis.gl/react-google-maps';
import { Crosshair, Maximize2 } from 'lucide-react';
import type { Station } from '../types/station.ts';

interface StationMapProps {
  stations: Station[];
  selectedStation: Station | null;
  onSelectStation: (station: Station) => void;
  infoWindowOpen: boolean;
  onCloseInfoWindow: () => void;
  isPickingLocation: boolean;
  onPickCoordinates: (lat: number, lng: number) => void;
  onCancelPicking: () => void;
  draftCoordinates: { lat: number; lng: number } | null;
}

type MapTypeOption = 'roadmap' | 'satellite' | 'terrain';

const DEFAULT_CENTER = { lat: -34.8254, lng: -58.0853 };

interface StationMarkerProps {
  station: Station;
  isSelected: boolean;
  infoWindowOpen: boolean;
  onSelect: (station: Station) => void;
  onCloseInfoWindow: () => void;
}

function StationMarker({
  station,
  isSelected,
  infoWindowOpen,
  onSelect,
  onCloseInfoWindow,
}: StationMarkerProps) {
  const [markerRef, marker] = useAdvancedMarkerRef();

  const isUpstream = station.tramo === 'aguas arriba';
  const pinBackground = isSelected
    ? '#d97706'
    : isUpstream
      ? '#0f766e'
      : '#1d4ed8';
  const pinBorder = isSelected
    ? '#92400e'
    : isUpstream
      ? '#115e59'
      : '#1e3a8a';

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat: station.latitud, lng: station.longitud }}
        title={`${station.nombre_punto} (${station.tramo})`}
        zIndex={isSelected ? 1000 : 10}
        onClick={() => onSelect(station)}
      >
        <Pin
          background={pinBackground}
          borderColor={pinBorder}
          glyphColor="#ffffff"
          scale={isSelected ? 1.25 : 1.0}
        />
      </AdvancedMarker>

      {isSelected && infoWindowOpen && marker && (
        <InfoWindow
          anchor={marker}
          pixelOffset={[0, -4]}
          maxWidth={290}
          onCloseClick={onCloseInfoWindow}
        >
          <div className="p-1 text-slate-900">
            <p className="font-display text-sm font-semibold leading-snug text-slate-900">
              {station.nombre_punto}
            </p>
            <p className="mt-1 text-xs text-slate-600">
              {station.arroyo} · <span className="font-medium capitalize">{station.tramo}</span>
            </p>
            <p className="mt-0.5 text-xs text-slate-500 tabular-nums">
              Muestreo: {station.fecha_muestreo}
            </p>
            <p className="mt-1.5 border-t border-slate-200 pt-1.5 font-mono text-[11px] text-slate-700 tabular-nums">
              {station.latitud.toFixed(6)}, {station.longitud.toFixed(6)}
            </p>
          </div>
        </InfoWindow>
      )}
    </>
  );
}

function MapCameraController({
  stations,
  selectedStation,
  fitTrigger,
}: {
  stations: Station[];
  selectedStation: Station | null;
  fitTrigger: number;
}) {
  const map = useMap();
  const coreLib = useMapsLibrary('core');

  useEffect(() => {
    if (!map || !selectedStation) return;
    map.panTo({ lat: selectedStation.latitud, lng: selectedStation.longitud });
    const currentZoom = map.getZoom();
    if (typeof currentZoom === 'number' && currentZoom < 13) {
      map.setZoom(14);
    }
  }, [map, selectedStation]);

  useEffect(() => {
    if (!map || !coreLib || stations.length === 0) return;
    if (fitTrigger === 0 && selectedStation) return;

    if (stations.length === 1) {
      map.panTo({ lat: stations[0].latitud, lng: stations[0].longitud });
      map.setZoom(14);
      return;
    }

    const bounds = new coreLib.LatLngBounds();
    for (const st of stations) {
      bounds.extend({ lat: st.latitud, lng: st.longitud });
    }
    map.fitBounds(bounds, { top: 64, right: 48, bottom: 48, left: 48 });
  }, [map, coreLib, stations, fitTrigger, selectedStation]);

  return null;
}

export function StationMap({
  stations,
  selectedStation,
  onSelectStation,
  infoWindowOpen,
  onCloseInfoWindow,
  isPickingLocation,
  onPickCoordinates,
  onCancelPicking,
  draftCoordinates,
}: StationMapProps) {
  const isLoaded = useApiIsLoaded();
  const loadingStatus = useApiLoadingStatus();
  const [mapType, setMapType] = useState<MapTypeOption>('terrain');
  const [fitTrigger, setFitTrigger] = useState(0);

  const handleMapClick = useCallback(
    (ev: MapMouseEvent) => {
      if (!isPickingLocation || !ev.detail.latLng) return;
      const lat = Number(ev.detail.latLng.lat.toFixed(6));
      const lng = Number(ev.detail.latLng.lng.toFixed(6));
      onPickCoordinates(lat, lng);
    },
    [isPickingLocation, onPickCoordinates]
  );

  if (loadingStatus === APILoadingStatus.FAILED || loadingStatus === APILoadingStatus.AUTH_FAILURE) {
    return (
      <div className="flex h-full min-h-[440px] flex-col items-center justify-center rounded-lg border border-slate-200 bg-slate-100 p-6 text-center">
        <p className="font-display text-base font-semibold text-slate-900">
          No se pudo cargar Google Maps
        </p>
        <p className="mt-1.5 max-w-md text-sm text-slate-600">
          Verificá que la clave de Google Maps Platform esté habilitada y tenga permisos para Maps JavaScript API.
        </p>
      </div>
    );
  }

  return (
    <div className="relative h-full min-h-[440px] w-full overflow-hidden rounded-lg border border-slate-200 bg-slate-100">
      {/* Top-left overlay controls */}
      <div className="pointer-events-none absolute top-3 left-3 right-3 z-10 flex flex-wrap items-center justify-between gap-2">
        <div
          className="pointer-events-auto inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white/95 p-1 shadow-sm backdrop-blur-sm"
          role="group"
          aria-label="Tipo de mapa"
        >
          {(
            [
              { id: 'roadmap', label: 'Mapa' },
              { id: 'terrain', label: 'Terreno' },
              { id: 'satellite', label: 'Satélite' },
            ] as const
          ).map((option) => (
            <button
              key={option.id}
              type="button"
              onClick={() => setMapType(option.id)}
              className={`whitespace-nowrap shrink-0 rounded px-2.5 py-1 text-xs font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-sky-600 ${
                mapType === option.id
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => setFitTrigger((n) => n + 1)}
          disabled={stations.length === 0}
          className="pointer-events-auto inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-md border border-slate-200 bg-white/95 px-3 py-1.5 text-xs font-medium text-slate-700 shadow-sm backdrop-blur-sm transition-colors hover:bg-slate-50 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-sky-600"
        >
          <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Ajustar vista</span>
        </button>
      </div>

      {/* Map pick mode prompt */}
      {isPickingLocation && (
        <div className="absolute bottom-4 left-1/2 z-20 flex -translate-x-1/2 items-center gap-3 rounded-md border border-sky-700 bg-slate-900 px-4 py-2.5 text-xs text-white shadow-lg">
          <Crosshair className="h-4 w-4 shrink-0 text-sky-400" aria-hidden="true" />
          <span className="whitespace-nowrap font-medium">
            Hacé clic sobre el mapa para capturar las coordenadas GPS decimales
          </span>
          <button
            type="button"
            onClick={onCancelPicking}
            className="whitespace-nowrap shrink-0 rounded bg-slate-700 px-2.5 py-1 font-medium text-slate-100 hover:bg-slate-600"
          >
            Cancelar
          </button>
        </div>
      )}

      {!isLoaded && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-100/80">
          <span className="text-sm font-medium text-slate-600">Cargando mapa...</span>
        </div>
      )}

      <GoogleMap
        mapId="DEMO_MAP_ID"
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        defaultCenter={
          selectedStation
            ? { lat: selectedStation.latitud, lng: selectedStation.longitud }
            : stations[0]
              ? { lat: stations[0].latitud, lng: stations[0].longitud }
              : DEFAULT_CENTER
        }
        defaultZoom={12}
        mapTypeId={mapType}
        gestureHandling="greedy"
        disableDefaultUI={false}
        streetViewControl={false}
        mapTypeControl={false}
        fullscreenControl={false}
        onClick={handleMapClick}
        style={{
          width: '100%',
          height: '100%',
          cursor: isPickingLocation ? 'crosshair' : 'grab',
        }}
      >
        <MapCameraController
          stations={stations}
          selectedStation={selectedStation}
          fitTrigger={fitTrigger}
        />

        {stations.map((station) => (
          <StationMarker
            key={station.id}
            station={station}
            isSelected={selectedStation?.id === station.id}
            infoWindowOpen={infoWindowOpen}
            onSelect={onSelectStation}
            onCloseInfoWindow={onCloseInfoWindow}
          />
        ))}

        {draftCoordinates && (
          <AdvancedMarker
            position={draftCoordinates}
            title="Ubicación temporal del formulario"
            zIndex={1100}
          >
            <Pin
              background="#0284c7"
              borderColor="#075985"
              glyphColor="#ffffff"
              scale={1.15}
            />
          </AdvancedMarker>
        )}
      </GoogleMap>
    </div>
  );
}
