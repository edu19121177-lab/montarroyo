import { useCallback, useEffect, useMemo, useState } from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';
import { MapPin, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { StationMap } from './components/StationMap.tsx';
import { StationFormModal } from './components/StationFormModal.tsx';
import { SchemaReferenceModal } from './components/SchemaReferenceModal.tsx';
import type { Station, StationInput, Tramo } from './types/station.ts';

type TramoFilter = 'todos' | Tramo;

export default function App() {
  const [quotaExceeded, setQuotaExceeded] = useState(false);
  const [mapsApiKey, setMapsApiKey] = useState<string>(
    import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ''
  );
  const [configLoaded, setConfigLoaded] = useState(
    Boolean(import.meta.env.VITE_GOOGLE_MAPS_API_KEY)
  );

  const [stations, setStations] = useState<Station[]>([]);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  const [tramoFilter, setTramoFilter] = useState<TramoFilter>('todos');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [infoWindowOpen, setInfoWindowOpen] = useState(true);

  const [formOpen, setFormOpen] = useState(false);
  const [formSessionKey, setFormSessionKey] = useState(0);
  const [editingStation, setEditingStation] = useState<Station | null>(null);
  const [isPickingLocation, setIsPickingLocation] = useState(false);
  const [pickedCoordinates, setPickedCoordinates] = useState<{ lat: number; lng: number } | null>(
    null
  );
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [schemaModalOpen, setSchemaModalOpen] = useState(false);

  // Listen to Tier 1/2 Google Maps quota exceeded event
  useEffect(() => {
    const handler = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handler);
    return () => window.removeEventListener('gmp-quota-exceeded', handler);
  }, []);

  // Load runtime config if VITE_GOOGLE_MAPS_API_KEY was not embedded at build time
  useEffect(() => {
    if (mapsApiKey) {
      setConfigLoaded(true);
      return;
    }
    fetch('/api/config')
      .then((res) => res.json())
      .then((data: { googleMapsApiKey?: string }) => {
        if (data.googleMapsApiKey) {
          setMapsApiKey(data.googleMapsApiKey);
        }
      })
      .catch(() => {
        // Handled by fallback UI
      })
      .finally(() => setConfigLoaded(true));
  }, [mapsApiKey]);

  const loadStations = useCallback(async () => {
    setLoading(true);
    setFetchError(null);
    try {
      const res = await fetch('/api/stations');
      if (!res.ok) {
        throw new Error('No se pudieron cargar las estaciones de monitoreo.');
      }
      const data = (await res.json()) as Station[];
      setStations(data);
      setSelectedId((prev) => {
        if (prev && data.some((s) => s.id === prev)) return prev;
        return data[0]?.id ?? null;
      });
    } catch (err) {
      setFetchError(
        err instanceof Error ? err.message : 'Error de conexión al cargar registros.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStations();
  }, [loadStations]);

  const filteredStations = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return stations.filter((station) => {
      const matchesTramo = tramoFilter === 'todos' || station.tramo === tramoFilter;
      if (!matchesTramo) return false;
      if (!query) return true;
      return (
        station.nombre_punto.toLowerCase().includes(query) ||
        station.arroyo.toLowerCase().includes(query)
      );
    });
  }, [stations, tramoFilter, searchQuery]);

  // Keep selected station aligned with visible filtered stations when filter changes
  useEffect(() => {
    if (filteredStations.length === 0) return;
    if (!selectedId || !filteredStations.some((s) => s.id === selectedId)) {
      setSelectedId(filteredStations[0].id);
    }
  }, [filteredStations, selectedId]);

  const selectedStation = useMemo(() => {
    return filteredStations.find((s) => s.id === selectedId) ?? null;
  }, [filteredStations, selectedId]);

  const upstreamCount = useMemo(
    () => stations.filter((s) => s.tramo === 'aguas arriba').length,
    [stations]
  );
  const downstreamCount = useMemo(
    () => stations.filter((s) => s.tramo === 'aguas abajo').length,
    [stations]
  );

  const handleSelectStation = useCallback((station: Station) => {
    setSelectedId(station.id);
    setInfoWindowOpen(true);
  }, []);

  const handleOpenCreate = () => {
    setEditingStation(null);
    setPickedCoordinates(null);
    setIsPickingLocation(false);
    setFormSessionKey((k) => k + 1);
    setFormOpen(true);
  };

  const handleOpenEdit = (station: Station) => {
    setEditingStation(station);
    setPickedCoordinates(null);
    setIsPickingLocation(false);
    setFormSessionKey((k) => k + 1);
    setFormOpen(true);
  };

  const handleSaveStation = async (input: StationInput, editingId?: string) => {
    const endpoint = editingId ? `/api/stations/${editingId}` : '/api/stations';
    const method = editingId ? 'PUT' : 'POST';

    const res = await fetch(endpoint, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    });

    const payload = await res.json();
    if (!res.ok) {
      const fieldMsg = payload.fieldErrors
        ? Object.values(payload.fieldErrors as Record<string, string>)[0]
        : null;
      throw new Error(fieldMsg || payload.error || 'No se pudo guardar el punto.');
    }

    const saved = payload as Station;
    await loadStations();
    setSelectedId(saved.id);
    setInfoWindowOpen(true);
    setPickedCoordinates(null);
  };

  const handleConfirmDelete = async (id: string) => {
    setDeletingId(id);
    try {
      const res = await fetch(`/api/stations/${id}`, { method: 'DELETE' });
      if (!res.ok) {
        throw new Error('No se pudo eliminar el registro.');
      }
      setPendingDeleteId(null);
      await loadStations();
    } catch (err) {
      setFetchError(err instanceof Error ? err.message : 'Error al eliminar el registro.');
    } finally {
      setDeletingId(null);
    }
  };

  const handleStartPickingOnMap = () => {
    setFormOpen(false);
    setIsPickingLocation(true);
  };

  const handlePickCoordinates = useCallback((lat: number, lng: number) => {
    setPickedCoordinates({ lat, lng });
    setIsPickingLocation(false);
    setFormOpen(true);
  }, []);

  const handleCancelPicking = useCallback(() => {
    setIsPickingLocation(false);
    setFormOpen(true);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {quotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* Three-Zone Top Bar */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-8 px-4 py-3.5 sm:px-6">
          <a
            href="#mapa"
            className="font-display text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 sm:text-lg"
          >
            Estaciones de monitoreo
          </a>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a
              href="#registros"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Registros
            </a>
            <a
              href="#mapa"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Mapa GPS
            </a>
            <button
              type="button"
              onClick={() => setSchemaModalOpen(true)}
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Esquema SQL
            </button>
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={handleOpenCreate}
              className="inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-md bg-sky-700 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-sky-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700"
            >
              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Nueva estación</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6">
        {/* Compact field context & summary row */}
        <section className="mb-5 flex flex-wrap items-baseline justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <h1 className="font-display text-xl font-bold text-slate-900 sm:text-2xl text-balance">
              Monitoreo comparativo de arroyos
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              Seleccioná una estación de muestreo para inspeccionar su ubicación exacta en grados decimales sobre el mapa.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-600 tabular-nums">
            <span className="font-mono font-medium text-slate-900">{stations.length}</span>
            <span>puntos totales</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono font-medium text-teal-700">{upstreamCount}</span>
            <span>aguas arriba</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono font-medium text-blue-700">{downstreamCount}</span>
            <span>aguas abajo</span>
          </div>
        </section>

        {fetchError && (
          <div className="mb-4 flex items-center justify-between rounded-md border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
            <span>{fetchError}</span>
            <button
              type="button"
              onClick={loadStations}
              className="whitespace-nowrap rounded border border-rose-300 bg-white px-3 py-1 text-xs font-medium text-rose-800 hover:bg-rose-50"
            >
              Reintentar
            </button>
          </div>
        )}

        {/* Asymmetric Split Workspace */}
        <div className="flex flex-col gap-5 lg:flex-row lg:items-stretch">
          {/* Left Panel: Filters + Stations List */}
          <section
            id="registros"
            className="flex w-full flex-col rounded-lg border border-slate-200 bg-white lg:w-[440px] lg:shrink-0"
          >
            <div className="space-y-3 border-b border-slate-200 p-4">
              <div className="relative">
                <Search
                  className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400"
                  aria-hidden="true"
                />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar por nombre o arroyo..."
                  aria-label="Buscar estaciones por nombre o arroyo"
                  className="w-full rounded-md border border-slate-200 bg-slate-50 py-2 pr-3 pl-9 text-sm text-slate-900 placeholder:text-slate-400 focus:border-sky-600 focus:bg-white focus:outline-none"
                />
              </div>

              {/* Segmented Filter Control for Tramo */}
              <div
                className="grid grid-cols-3 gap-1 rounded-md bg-slate-100 p-1"
                role="group"
                aria-label="Filtrar por tramo del arroyo"
              >
                {(
                  [
                    { id: 'todos', label: 'Todos' },
                    { id: 'aguas arriba', label: 'Aguas arriba' },
                    { id: 'aguas abajo', label: 'Aguas abajo' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setTramoFilter(tab.id)}
                    className={`whitespace-nowrap shrink-0 rounded px-2.5 py-1.5 text-xs font-medium transition-colors focus-visible:outline-2 focus-visible:outline-sky-600 ${
                      tramoFilter === tab.id
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex-1 divide-y divide-slate-200 overflow-y-auto lg:max-h-[calc(100vh-19rem)]">
              {loading ? (
                <div className="space-y-3 p-4">
                  {[1, 2, 3].map((n) => (
                    <div
                      key={n}
                      className="h-20 animate-pulse rounded-md border border-slate-100 bg-slate-100"
                    />
                  ))}
                </div>
              ) : filteredStations.length === 0 ? (
                <div className="flex flex-col items-center justify-center px-6 py-12 text-center">
                  <MapPin className="h-7 w-7 text-slate-300" aria-hidden="true" />
                  <p className="mt-3 font-display text-sm font-semibold text-slate-800">
                    Sin estaciones para mostrar
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    {tramoFilter !== 'todos' || searchQuery
                      ? 'Probá cambiando el filtro de tramo o el texto de búsqueda.'
                      : 'Agregá el primer punto de muestreo del equipo.'}
                  </p>
                  <button
                    type="button"
                    onClick={
                      tramoFilter !== 'todos' || searchQuery
                        ? () => {
                            setTramoFilter('todos');
                            setSearchQuery('');
                          }
                        : handleOpenCreate
                    }
                    className="mt-4 whitespace-nowrap rounded-md border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
                  >
                    {tramoFilter !== 'todos' || searchQuery
                      ? 'Mostrar todas las estaciones'
                      : 'Agregar primera estación'}
                  </button>
                </div>
              ) : (
                filteredStations.map((station) => {
                  const isSelected = selectedStation?.id === station.id;
                  const isConfirmingDelete = pendingDeleteId === station.id;

                  return (
                    <div
                      key={station.id}
                      className={`transition-colors ${
                        isSelected ? 'bg-sky-50/75' : 'bg-white hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3 p-4">
                        <button
                          type="button"
                          onClick={() => handleSelectStation(station)}
                          className="min-w-0 flex-1 text-left focus-visible:outline-2 focus-visible:outline-sky-600"
                        >
                          <p className="truncate font-display text-sm font-semibold text-slate-900">
                            {station.nombre_punto}
                          </p>
                          <div className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs text-slate-600">
                            <span>{station.arroyo}</span>
                            <span aria-hidden="true">·</span>
                            <span
                              className={`font-medium capitalize ${
                                station.tramo === 'aguas arriba'
                                  ? 'text-teal-700'
                                  : 'text-blue-700'
                              }`}
                            >
                              {station.tramo}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono text-[11px] text-slate-500 tabular-nums">
                              {station.fecha_muestreo}
                            </span>
                          </div>
                          <p className="mt-1.5 font-mono text-xs text-slate-700 tabular-nums">
                            {station.latitud.toFixed(6)}, {station.longitud.toFixed(6)}
                          </p>
                        </button>

                        <div className="flex shrink-0 items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(station)}
                            aria-label={`Editar ${station.nombre_punto}`}
                            title="Editar"
                            className="rounded p-1.5 text-slate-500 transition-colors hover:bg-slate-200/70 hover:text-slate-900 focus-visible:outline-2 focus-visible:outline-sky-600"
                          >
                            <Pencil className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setPendingDeleteId(isConfirmingDelete ? null : station.id)
                            }
                            aria-label={`Eliminar ${station.nombre_punto}`}
                            title="Eliminar"
                            className="rounded p-1.5 text-slate-500 transition-colors hover:bg-rose-50 hover:text-rose-700 focus-visible:outline-2 focus-visible:outline-rose-600"
                          >
                            <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                        </div>
                      </div>

                      {isConfirmingDelete && (
                        <div className="flex items-center justify-between gap-2 border-t border-rose-100 bg-rose-50/80 px-4 py-2.5 text-xs">
                          <span className="font-medium text-rose-900">
                            ¿Eliminar este punto de muestreo?
                          </span>
                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={() => setPendingDeleteId(null)}
                              className="rounded border border-slate-300 bg-white px-2.5 py-1 font-medium text-slate-700 hover:bg-slate-50"
                            >
                              Cancelar
                            </button>
                            <button
                              type="button"
                              disabled={deletingId === station.id}
                              onClick={() => handleConfirmDelete(station.id)}
                              className="rounded bg-rose-700 px-2.5 py-1 font-medium text-white hover:bg-rose-800 disabled:opacity-60"
                            >
                              {deletingId === station.id ? 'Eliminando...' : 'Eliminar'}
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </section>

          {/* Right Stage: Google Map + Selected Record Detail */}
          <section id="mapa" className="flex min-w-0 flex-1 flex-col gap-4">
            <div className="h-[460px] lg:h-[calc(100vh-17.5rem)] min-h-[440px]">
              {!configLoaded ? (
                <div className="flex h-full items-center justify-center rounded-lg border border-slate-200 bg-slate-100">
                  <span className="text-sm text-slate-600">Inicializando visor de mapa...</span>
                </div>
              ) : !mapsApiKey ? (
                <div className="flex h-full flex-col items-center justify-center rounded-lg border border-slate-200 bg-slate-100 p-6 text-center">
                  <p className="font-display text-base font-semibold text-slate-900">
                    Clave de Google Maps no disponible
                  </p>
                  <p className="mt-1 max-w-md text-sm text-slate-600">
                    Habilitá Google Maps Platform en la configuración del proyecto para visualizar los marcadores GPS.
                  </p>
                </div>
              ) : (
                <APIProvider
                  apiKey={mapsApiKey}
                  libraries={['marker']}
                  language="es"
                  region="AR"
                >
                  <StationMap
                    stations={filteredStations}
                    selectedStation={selectedStation}
                    onSelectStation={handleSelectStation}
                    infoWindowOpen={infoWindowOpen}
                    onCloseInfoWindow={() => setInfoWindowOpen(false)}
                    isPickingLocation={isPickingLocation}
                    onPickCoordinates={handlePickCoordinates}
                    onCancelPicking={handleCancelPicking}
                    draftCoordinates={pickedCoordinates}
                  />
                </APIProvider>
              )}
            </div>

            {/* Selected Station Telemetry Strip */}
            <div className="rounded-lg border border-slate-200 bg-white px-5 py-4">
              {selectedStation ? (
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
                  <div className="col-span-2 sm:col-span-1 lg:col-span-2">
                    <p className="text-[11px] font-medium text-slate-500">Punto seleccionado</p>
                    <p className="mt-0.5 truncate font-display text-sm font-semibold text-slate-900">
                      {selectedStation.nombre_punto}
                    </p>
                    <p className="mt-0.5 truncate font-mono text-[11px] text-slate-400">
                      ID: {selectedStation.id}
                    </p>
                  </div>

                  <div>
                    <p className="text-[11px] font-medium text-slate-500">Arroyo</p>
                    <p className="mt-0.5 text-sm font-medium text-slate-900">
                      {selectedStation.arroyo}
                    </p>
                  </div>

                  <div>
                    <p className="text-[11px] font-medium text-slate-500">Tramo</p>
                    <p
                      className={`mt-0.5 text-sm font-semibold capitalize ${
                        selectedStation.tramo === 'aguas arriba'
                          ? 'text-teal-700'
                          : 'text-blue-700'
                      }`}
                    >
                      {selectedStation.tramo}
                    </p>
                  </div>

                  <div>
                    <p className="text-[11px] font-medium text-slate-500">Fecha de muestreo</p>
                    <p className="mt-0.5 font-mono text-sm text-slate-900 tabular-nums">
                      {selectedStation.fecha_muestreo}
                    </p>
                  </div>

                  <div>
                    <p className="text-[11px] font-medium text-slate-500">Coordenadas decimales</p>
                    <p className="mt-0.5 font-mono text-xs font-medium text-slate-900 tabular-nums">
                      {selectedStation.latitud.toFixed(6)}, {selectedStation.longitud.toFixed(6)}
                    </p>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-slate-500">
                  Seleccioná un registro de la lista o un marcador del mapa para ver sus coordenadas y datos de muestreo.
                </p>
              )}
            </div>
          </section>
        </div>
      </main>

      <StationFormModal
        isOpen={formOpen}
        formSessionKey={formSessionKey}
        editingStation={editingStation}
        pickedCoordinates={pickedCoordinates}
        onStartPickingOnMap={handleStartPickingOnMap}
        onClose={() => {
          setFormOpen(false);
          setPickedCoordinates(null);
        }}
        onSave={handleSaveStation}
      />

      <SchemaReferenceModal
        isOpen={schemaModalOpen}
        onClose={() => setSchemaModalOpen(false)}
      />
    </div>
  );
}
