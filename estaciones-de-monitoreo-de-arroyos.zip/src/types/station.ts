export type Tramo = 'aguas arriba' | 'aguas abajo';

export interface Station {
  id: string;
  nombre_punto: string;
  latitud: number;
  longitud: number;
  arroyo: string;
  fecha_muestreo: string;
  tramo: Tramo;
  created_at: string;
}

export interface StationInput {
  nombre_punto: string;
  latitud: number;
  longitud: number;
  arroyo: string;
  fecha_muestreo: string;
  tramo: Tramo;
}

export interface ValidationResult {
  ok: boolean;
  data?: StationInput;
  errors: Record<string, string>;
}

export const INITIAL_STATIONS_SEED: Station[] = [
  {
    id: '4f7e2a10-6c1d-4d2e-9b18-100100000001',
    nombre_punto: 'Naciente Parque Pereyra',
    latitud: -34.84215,
    longitud: -58.11842,
    arroyo: 'Arroyo Pereyra',
    fecha_muestreo: '2026-11-10',
    tramo: 'aguas arriba',
    created_at: '2026-11-10T10:15:00.000Z',
  },
  {
    id: '4f7e2a10-6c1d-4d2e-9b18-100100000002',
    nombre_punto: 'Puente Ruta 2 Km 41',
    latitud: -34.82864,
    longitud: -58.09531,
    arroyo: 'Arroyo Pereyra',
    fecha_muestreo: '2026-11-12',
    tramo: 'aguas arriba',
    created_at: '2026-11-12T14:20:00.000Z',
  },
  {
    id: '4f7e2a10-6c1d-4d2e-9b18-100100000003',
    nombre_punto: 'Desembocadura Punta Lara',
    latitud: -34.80548,
    longitud: -58.04219,
    arroyo: 'Arroyo Pereyra',
    fecha_muestreo: '2026-11-15',
    tramo: 'aguas abajo',
    created_at: '2026-11-15T16:40:00.000Z',
  },
];

export function parseDecimalCoordinate(raw: unknown): number | null {
  if (typeof raw === 'number') {
    return Number.isFinite(raw) ? raw : null;
  }
  if (typeof raw === 'string') {
    const trimmed = raw.trim().replace(',', '.');
    if (trimmed === '' || !/^-?\d+(\.\d+)?$/.test(trimmed)) {
      return null;
    }
    const parsed = Number(trimmed);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

export function validateLatitude(raw: unknown): { valid: boolean; value?: number; error?: string } {
  const num = parseDecimalCoordinate(raw);
  if (num === null) {
    return { valid: false, error: 'Ingresá una latitud válida en grados decimales.' };
  }
  if (num < -90 || num > 90) {
    return { valid: false, error: 'La latitud debe estar entre -90 y 90 grados decimales.' };
  }
  return { valid: true, value: Number(num.toFixed(6)) };
}

export function validateLongitude(raw: unknown): { valid: boolean; value?: number; error?: string } {
  const num = parseDecimalCoordinate(raw);
  if (num === null) {
    return { valid: false, error: 'Ingresá una longitud válida en grados decimales.' };
  }
  if (num < -180 || num > 180) {
    return { valid: false, error: 'La longitud debe estar entre -180 y 180 grados decimales.' };
  }
  return { valid: true, value: Number(num.toFixed(6)) };
}

export function validateStationInput(raw: unknown): ValidationResult {
  const errors: Record<string, string> = {};
  if (!raw || typeof raw !== 'object') {
    return { ok: false, errors: { general: 'Datos inválidos.' } };
  }

  const record = raw as Record<string, unknown>;
  const nombrePunto = typeof record.nombre_punto === 'string' ? record.nombre_punto.trim() : '';
  const arroyo = typeof record.arroyo === 'string' ? record.arroyo.trim() : '';
  const fechaMuestreo = typeof record.fecha_muestreo === 'string' ? record.fecha_muestreo.trim() : '';
  const tramoRaw = typeof record.tramo === 'string' ? record.tramo.trim().toLowerCase() : '';

  if (nombrePunto.length < 2) {
    errors.nombre_punto = 'El nombre del punto debe tener al menos 2 caracteres.';
  }
  if (arroyo.length < 2) {
    errors.arroyo = 'Ingresá el nombre del arroyo.';
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fechaMuestreo)) {
    errors.fecha_muestreo = 'Seleccioná una fecha de muestreo válida (AAAA-MM-DD).';
  }
  if (tramoRaw !== 'aguas arriba' && tramoRaw !== 'aguas abajo') {
    errors.tramo = 'Seleccioná un tramo válido: aguas arriba o aguas abajo.';
  }

  const latCheck = validateLatitude(record.latitud);
  if (!latCheck.valid && latCheck.error) {
    errors.latitud = latCheck.error;
  }

  const lngCheck = validateLongitude(record.longitud);
  if (!lngCheck.valid && lngCheck.error) {
    errors.longitud = lngCheck.error;
  }

  if (Object.keys(errors).length > 0) {
    return { ok: false, errors };
  }

  return {
    ok: true,
    errors: {},
    data: {
      nombre_punto: nombrePunto,
      arroyo,
      fecha_muestreo: fechaMuestreo,
      tramo: tramoRaw as Tramo,
      latitud: latCheck.value!,
      longitud: lngCheck.value!,
    },
  };
}
