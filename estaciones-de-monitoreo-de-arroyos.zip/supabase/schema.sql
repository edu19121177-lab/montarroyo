-- Esquema de tabla en Supabase para Estaciones de monitoreo de arroyos
create extension if not exists "pgcrypto";

create table if not exists public.estaciones_monitoreo (
  id uuid primary key default gen_random_uuid(),
  nombre_punto text not null,
  latitud double precision not null check (latitud >= -90 and latitud <= 90),
  longitud double precision not null check (longitud >= -180 and longitud <= 180),
  arroyo text not null,
  fecha_muestreo date not null,
  tramo text not null check (tramo in ('aguas arriba', 'aguas abajo')),
  created_at timestamptz not null default now()
);

-- Índices para filtrar por tramo y ordenar por fecha de muestreo
create index if not exists idx_estaciones_tramo
  on public.estaciones_monitoreo (tramo);

create index if not exists idx_estaciones_fecha
  on public.estaciones_monitoreo (fecha_muestreo desc);

-- Habilitar Row Level Security (ajustar políticas según requerimientos de autenticación)
alter table public.estaciones_monitoreo enable row level security;

create policy "Lectura pública de estaciones"
  on public.estaciones_monitoreo for select
  using (true);

create policy "Inserción pública de estaciones"
  on public.estaciones_monitoreo for insert
  with check (true);

create policy "Actualización pública de estaciones"
  on public.estaciones_monitoreo for update
  using (true)
  with check (true);

create policy "Eliminación pública de estaciones"
  on public.estaciones_monitoreo for delete
  using (true);

-- Tres ejemplos iniciales en ubicaciones distintas
insert into public.estaciones_monitoreo (
  nombre_punto,
  latitud,
  longitud,
  arroyo,
  fecha_muestreo,
  tramo
) values
  (
    'Naciente Parque Pereyra',
    -34.842150,
    -58.118420,
    'Arroyo Pereyra',
    '2026-11-10',
    'aguas arriba'
  ),
  (
    'Puente Ruta 2 Km 41',
    -34.828640,
    -58.095310,
    'Arroyo Pereyra',
    '2026-11-12',
    'aguas arriba'
  ),
  (
    'Desembocadura Punta Lara',
    -34.805480,
    -58.042190,
    'Arroyo Pereyra',
    '2026-11-15',
    'aguas abajo'
  );
